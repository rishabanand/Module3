package com.cg.dao;

import java.util.ArrayList;

import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;

public interface ElecBillDao
{
	public int addBillDetails(ElectricityBill elecBill) throws Exception,BillException;
	public int generateBillNumber() throws Exception,BillException;
	public ArrayList<Integer> getConsumerNo() throws Exception,BillException;
	public String getConsumerName(int consumerNumber) throws Exception,BillException;
}
