package com.cg.service;

import com.cg.dto.ElectricityBill;
import com.cg.exception.BillException;

public interface ElecBillService 
{
	public int addBillDetails(ElectricityBill elecBill) throws BillException,Exception;
	public int generateBillNumber() throws BillException,Exception;

	
	public float calcUnitConsumed(float lMonMeterReading,float cMonMeterReading)throws BillException,Exception;
	public float calcNetAmount(float unitConsumed)throws BillException,Exception;
	public String getConsumerName(int ConsumerNumber) throws BillException,Exception;
	
	public boolean validateLMonMeterReading(float lMonMeterReading) throws BillException,Exception;
	public boolean validateCMonMeterReading(float cMonMeterReading) throws BillException,Exception;
	public boolean validateMeterReading(float lMonMeterReading,float cMonMeterReading)throws BillException,Exception;
	public boolean validateConsumerNumber(int consumerNumber) throws BillException, Exception;
}
