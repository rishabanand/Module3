package com.cg.user.ui;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/SuccessPage")
public class SuccessPage extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    ServletConfig cg=null;
    
    public SuccessPage() 
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession(true);
		String name=(String)session.getAttribute("UserNameObj");
		out.println("<b> Welcome To EMS: </b> "+name);
		out.println(" <b>You are a valid User: </b>");
		out.println("<hr color='green' size='3'>");
		out.print("You can perform all Emp Operation");
		out.println("<a href=''>Add Emp</a><br>");
		out.println("<a href=''>List ALL Emp</a><br>");
		out.println("<a href=''>Delete Emp</a><br>");
		out.println("<a href=''>Update Emp</a><br>");
	}

}
