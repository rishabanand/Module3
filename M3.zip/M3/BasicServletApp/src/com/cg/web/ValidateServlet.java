package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;
import com.cg.service.LoginService;
import com.cg.service.LoginServiceImpl;


@WebServlet("/ValidateServlet")
public class ValidateServlet extends HttpServlet 
{
	LoginService logService=null;
	private static final long serialVersionUID = 1L;
       
    
    public ValidateServlet()
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		logService=new LoginServiceImpl();
		String unm=request.getParameter("txtUsername");
		String pwd=request.getParameter("txtPassword");
		try 
		{
			Login urs=logService.getUserByUnm(unm);
			if(urs.getUserName().equalsIgnoreCase(unm) && urs.getPassword().equalsIgnoreCase(pwd))
			{
				RequestDispatcher rdSuccess=request.getRequestDispatcher("SuccessServlet");
				rdSuccess.forward(request, response);
			}
			else
			{
				RequestDispatcher rdFailure=request.getRequestDispatcher("html/login.html");
				rdFailure.forward(request, response);
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
}
