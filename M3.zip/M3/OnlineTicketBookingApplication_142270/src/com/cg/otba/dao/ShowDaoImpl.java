package com.cg.otba.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.otba.dto.Show;
import com.cg.otba.exception.TicketBookingException;
import com.cg.otba.util.DBUtil;

public class ShowDaoImpl implements ShowDao
{
	Connection con=null;
	PreparedStatement pst=null;
	Statement st=null;
	ResultSet rs=null;
	/*
	 This getShowDetails function is used to get all details from the showDetails table 
	 */
	@Override
	public ArrayList<Show> getShowDetails() throws TicketBookingException 
	{
		ArrayList<Show> showList=new ArrayList<Show>();
		String selectqry="SELECT * FROM ShowDetails";
		Show show=null;
		
		try 
		{
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectqry);
			
			while(rs.next())
			{
				show=new Show();
				show.setShowName(rs.getString("ShowName"));
				show.setLocation(rs.getString("Location"));
				show.setShowDate(rs.getDate("ShowDate").toLocalDate());
				show.setPriceTicket(rs.getFloat("PriceTicket"));
				show.setAvailableSeats(rs.getInt("AvSeats"));
				showList.add(show);
			}			
		}
		catch (Exception e) 
		{
			throw new TicketBookingException("Problem in fetching Show list"+e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new TicketBookingException(e.getMessage());				
			}
			
		}
		return showList;		
	}
	
	/* This method is used to update the no of Available seats in the table ShowDetails table*/
	@Override
	public int updateSeats(int noOfSeatsToBook,String showName)
			throws TicketBookingException
	{	
		String updateQry="UPDATE  ShowDetails SET AvSeats=AvSeats-? WHERE ShowName=?";
		int dataUpdated=0;
		try
		{
			con=DBUtil.getCon();
			pst=con.prepareStatement(updateQry);
			pst.setInt(1,noOfSeatsToBook);
			pst.setString(2, showName);
			dataUpdated=pst.executeUpdate();			
		} 
		catch (Exception e) 
		{	
			throw new TicketBookingException("Problem in updating the No Of Seats "+e.getMessage());
		}
		finally
		{
			try 
			{
				pst.close();
				con.close();
			} 
			catch (SQLException e)
			{
				throw new TicketBookingException(e.getMessage());
			}			
		}
		return dataUpdated;		
	}
}
