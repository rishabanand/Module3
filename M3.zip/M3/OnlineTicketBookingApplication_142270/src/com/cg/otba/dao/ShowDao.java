package com.cg.otba.dao;

import java.util.ArrayList;
import com.cg.otba.dto.Show;
import com.cg.otba.exception.TicketBookingException;

public interface ShowDao
{
	public ArrayList<Show> getShowDetails() throws TicketBookingException;
	public int updateSeats(int noOfSeatsToBook,String showName)throws TicketBookingException;
}
