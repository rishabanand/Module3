package com.cg.otba.service;

import java.util.ArrayList;

import com.cg.otba.dto.Show;
import com.cg.otba.exception.TicketBookingException;

public interface ShowService 
{
	public ArrayList<Show> getShowDetails() throws TicketBookingException;
	public int updateSeats(int noOfSeatsToBook,String showName)throws TicketBookingException;
	boolean validateSeats(int noOfSeatsToBook,int noOfSeatsAvailable)throws TicketBookingException;
	float calculateTotalPrice(float price,int noOfSeatsToBook)throws TicketBookingException;
}
