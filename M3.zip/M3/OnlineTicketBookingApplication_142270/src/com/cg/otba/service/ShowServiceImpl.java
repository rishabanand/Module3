package com.cg.otba.service;

import java.util.ArrayList;

import com.cg.otba.dao.ShowDao;
import com.cg.otba.dao.ShowDaoImpl;
import com.cg.otba.dto.Show;
import com.cg.otba.exception.TicketBookingException;

public class ShowServiceImpl implements ShowService
{
	ShowDao showDao=null;
	public ShowServiceImpl()
	{
		showDao=new ShowDaoImpl();
	}

	@Override
	public ArrayList<Show> getShowDetails() throws TicketBookingException 
	{		
		return showDao.getShowDetails();
	}

	@Override
	public int updateSeats(int noOfSeatsToBook, String showName)
			throws TicketBookingException 
	{	
		return showDao.updateSeats(noOfSeatsToBook, showName);
	}
	/* This validateSeats method is used to validate the no of seats to book should be greater than zero, 
	 	 a positive number and to validate that no of seats to book should be 
	 	 less than the no of seats available.
	 */
	@Override
	public boolean validateSeats(int noOfSeatsToBook, int noOfSeatsAvailable)
			throws TicketBookingException 
	{
		if(noOfSeatsToBook>0 && noOfSeatsToBook<=noOfSeatsAvailable)
		{
			return true;
		}
		else
		{
			throw new TicketBookingException("No of Seats to book should be positive and greater than zero and less than no of seats available");
		}		
	}
	/* This calculateTotalPrice method is used to calculate the total price to be paid by
	   the customer for all the tickets in total.
	  */

	@Override
	public float calculateTotalPrice(float price, int noOfSeatsToBook)//here price is the price for for single seat
			throws TicketBookingException 
	{
		float totalPrice=noOfSeatsToBook*price;
		return totalPrice;
	}
}
