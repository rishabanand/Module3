package com.cg.otba.exception;

public class TicketBookingException extends Exception
{

	public TicketBookingException()
	{
		super();
	}

	public TicketBookingException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public TicketBookingException(String message, Throwable cause) 
	{
		super(message, cause);
	}

	public TicketBookingException(String message)
	{
		super(message);
	}

	public TicketBookingException(Throwable cause) 
	{
		super(cause);		
	}
	
}
