package com.cg.otba.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.otba.dto.Show;
import com.cg.otba.exception.TicketBookingException;
import com.cg.otba.service.ShowService;
import com.cg.otba.service.ShowServiceImpl;


@WebServlet(urlPatterns={"/ShowController","/BookNow","/UpdateSeat"})
public class ShowController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	HttpSession session=null;
	ShowService showService=null;



	public void init(ServletConfig config) throws ServletException 
	{

	}


	public void destroy() 
	{

	}


	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		doPost(request,response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		showService=new ShowServiceImpl();
		session=request.getSession(true);
		String url=request.getServletPath();
		String targetUrl="";
		switch(url)
		{
		/* This case is used to forward the Customer to ShowDetails.jsp and It is also
		 	setting the values of show arrayList  in session object .
		 */
		case "/ShowController":
			ArrayList<Show> showList;
			try 
			{
				showList=showService.getShowDetails();
				session.setAttribute("showListObj", showList);
				targetUrl="ShowDetails.jsp";
			} 
			catch (TicketBookingException e)
			{
				//e.printStackTrace();
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}
			break;
			/* This case is used to forward the customer to BookNow.jsp to book the show for him
			   and also setting the values of showName,price and available seats 
			   which we are getting from Url Rewriting in session object.			 	
			 */
		case "/BookNow":
			String showName=request.getParameter("showName");
			float price=Float.parseFloat(request.getParameter("price"));
			int avaiSeats=Integer.parseInt(request.getParameter("avaiSeats"));
			session.setAttribute("showNameObj",showName);
			session.setAttribute("priceObj", price);
			session.setAttribute("avaiSeatsObj", avaiSeats);
			targetUrl="BookNow.jsp";
			break;
			/* This case is used to forward the customer to Success.jsp 
			 where he can see his booking details and also taking the values
			 from form which was written in BookNow.jsp and validating the 
			 no of seats to book and updating the No of seats available and setting 
			 the values of fields coming from Book Now from in session object.
			 */
		case "/UpdateSeat":
			int dataUpdated=0;
			String showNam=request.getParameter("txtShowName");
			float singleTicketprice=Float.parseFloat(request.getParameter("Price"));
			String cusName=request.getParameter("txtCusName");
			long mobileNo=Long.parseLong(request.getParameter("txtmobileNo"));
			int seatsAvailable=Integer.parseInt(request.getParameter("seatsAvai"));
			int noOfSeatsToBook=Integer.parseInt(request.getParameter("noOfSeats"));
			try 
			{
				if(showService.validateSeats(noOfSeatsToBook, seatsAvailable))
				{
					dataUpdated=showService.updateSeats(noOfSeatsToBook, showNam);
					if(dataUpdated==1)
					{
						float totalPrice=showService.calculateTotalPrice(singleTicketprice, noOfSeatsToBook);
						session.setAttribute("showNameObj", showNam);
						session.setAttribute("CustomerNameObj", cusName);
						session.setAttribute("MobileNoObj", mobileNo);
						session.setAttribute("NoOfSeatsObj", noOfSeatsToBook);
						session.setAttribute("TotalPrice", totalPrice);
						targetUrl="Success.jsp";
					}
				}				
			} 
			catch (TicketBookingException e) 
			{
				request.setAttribute("error", e.getMessage());
				targetUrl="Error.jsp";
			}

			break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(targetUrl);
		rd.forward(request, response);
	}

}
