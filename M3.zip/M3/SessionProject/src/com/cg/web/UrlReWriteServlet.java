package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UrlReWriteServlet")
public class UrlReWriteServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
    ServletConfig cg=null;
    int count=0;
    public UrlReWriteServlet()
    {
        super();
      
    }

	
	public void init(ServletConfig config) throws ServletException
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy() {
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		String iid=request.getParameter("id");
		if(iid==null)
		{
			iid="0";
			count=Integer.parseInt(iid);
			count++;
		}
		else
		{
			count=Integer.parseInt(iid);
			count++;
		}
		PrintWriter out=response.getWriter();
		out.println("<b> I was Visited :" +count+ " Times</b>");
		out.println("<br> Do You want to Visit me again ?");
		out.println("<a href='/SessionProject/UrlReWriteServlet?id="+count+"'> Click Here To Visit me Again</a>");
	}

}
