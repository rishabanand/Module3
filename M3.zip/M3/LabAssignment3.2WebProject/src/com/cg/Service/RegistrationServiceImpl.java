package com.cg.Service;

import java.sql.SQLException;

import com.cg.dao.RegistrationDao;
import com.cg.dao.RegistrationDaoImpl;
import com.cg.dto.Registration;

public class RegistrationServiceImpl implements RegistrationService
{
	RegistrationDao regDao=null;
	public RegistrationServiceImpl()
	{
		regDao=new RegistrationDaoImpl();
	}
	@Override
	public int addRegistrationDetails(Registration regInfo) throws SQLException {
		
		return regDao.addRegistrationDetails(regInfo);
	}

}
