package com.cg.web;

import java.io.IOException;
import java.sql.SQLException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.Service.RegistrationService;
import com.cg.Service.RegistrationServiceImpl;
import com.cg.dto.Registration;


@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
     RegistrationService regService=null;  
     Registration reg=null;
    public RegistrationServlet()
    {
        super();
        
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		
	}

	
	public void destroy()
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		regService=new RegistrationServiceImpl();
		String fName=request.getParameter("txtFName");
		String lName=request.getParameter("txtLName");
		String pwd=request.getParameter("txtPassword");
		String gen=request.getParameter("radio1");
		String skillSet[]=request.getParameterValues("skills");
	
		String city=request.getParameter("city");
		
		
		String finalSkills=String.join(",", skillSet) ;
		reg=new Registration(fName,lName,pwd,gen,finalSkills,city);
		
		try 
		{
			int dataAdded=regService.addRegistrationDetails(reg);
			if(dataAdded==1)
			{
				response.sendRedirect("html/RegistartionSuccess.html");
			}
			else
			{
				response.sendRedirect("html/RegistartionFailure.html");
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	
	}

}
