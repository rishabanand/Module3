package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Registration;
import com.cg.util.DBUtil;

public class RegistrationDaoImpl implements RegistrationDao
{
	Connection con=null;
	PreparedStatement pst=null;
	int dataAdded=0;
	@Override
	public int addRegistrationDetails(Registration regInfo) throws SQLException 
	{
		//System.out.println("dao****************"+regInfo);
		con=DBUtil.getCon();
		//System.out.println("Get Connection");
		String insertQry="INSERT INTO RegisteredUsers VALUES(?,?,?,?,?,?)";
		pst=con.prepareStatement(insertQry);
		pst.setString(1, regInfo.getFirstName());
		pst.setString(2, regInfo.getLastName());
		pst.setString(3, regInfo.getPassword());
		pst.setString(4, regInfo.getGender());
		pst.setString(5, regInfo.getSkillSet());
		pst.setString(6, regInfo.getCity());
		dataAdded=pst.executeUpdate();
		return dataAdded;
	}

}
