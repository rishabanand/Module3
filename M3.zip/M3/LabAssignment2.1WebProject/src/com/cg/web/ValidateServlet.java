package com.cg.web;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "ValidateServletName", urlPatterns = { "/ValidateServletMap" })
public class ValidateServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
    
    public ValidateServlet()
    {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException
	{
		
	}

	
	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String unm=request.getParameter("txtUserName");
		String pw=request.getParameter("txtPassword");
		if(validateUser(unm,pw))
		{
			response.sendRedirect("/LabAssignment2.1WebProject/Success.html");
		}
		else
		{
			response.sendRedirect("/LabAssignment2.1WebProject/Failure.html");
		}
	}
	private boolean validateUser(String unm,String pw) throws IOException
	{		
		if(unm.equals("Rishab") && pw.equals("Surekha341"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
