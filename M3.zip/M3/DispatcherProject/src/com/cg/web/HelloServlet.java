package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns={"/HelloServlet"},
initParams={@WebInitParam(name = "cityname", value = "pune")
,@WebInitParam(name="location",value="Talwade")})
public class HelloServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
    ServletConfig cg=null;  
    
    public HelloServlet() 
    {
        super();
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		cg=config;
	}

	
	public void destroy()
	{
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
	{
		String city=cg.getInitParameter("cityname");
		String loc=cg.getInitParameter("location");
		PrintWriter out=response.getWriter();
		RequestDispatcher rdHeader=request.getRequestDispatcher("HeaderServlet");
		RequestDispatcher rdFooter=request.getRequestDispatcher("html/Footer.html");
		
		String conType=response.getContentType();
		int portNo=request.getLocalPort();
		rdHeader.include(request, response);
		out.println("City :"+city+" Location :" +loc);
		out.println("<br> Mime Type Is : "+conType);
		out.println("Port No Is : "+portNo);
		rdFooter.include(request, response);
	}
}
