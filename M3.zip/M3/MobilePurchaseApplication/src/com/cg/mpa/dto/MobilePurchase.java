package com.cg.mpa.dto;

import java.time.LocalDate;

public class MobilePurchase 
{
	private long purchaseId ;
	private String customerName;
	private String phoneno;
	private LocalDate purchaseDate;
	private long mobileId;
	private String mailId;
	
	
	public String getMailId() 
	{
		return mailId;
	}


	public void setMailId(String mailId)
	{
		this.mailId = mailId;
	}


	public MobilePurchase() 
	{
		super();
	}


	public MobilePurchase(long purchaseId, String customerName, String phoneno,
			LocalDate purchaseDate, int mobileId) 
	{
		super();
		this.purchaseId = purchaseId;
		this.customerName = customerName;
		this.phoneno = phoneno;
		this.purchaseDate = purchaseDate;
		this.mobileId = mobileId;
	}


	public long getPurchaseId()
	{
		return purchaseId;
	}


	public void setPurchaseId(long purchaseId) 
	{
		this.purchaseId = purchaseId;
	}


	public String getCustomerName()
	{
		return customerName;
	}


	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}


	public String getPhoneno() 
	{
		return phoneno;
	}


	public void setPhoneno(String phoneno) 
	{
		this.phoneno = phoneno;
	}

	public long getMobileId() 
	{
		return mobileId;
	}


	public void setMobileId(long mobileId) 
	{
		this.mobileId = mobileId;
	}


	public LocalDate getPurchaseDate() {
		return purchaseDate;
	}


	public void setPurchaseDate(LocalDate purchaseDate) {
		this.purchaseDate = purchaseDate;
	}


	@Override
	public String toString() 
	{
		return "MobilePurchase [purchaseId=" + purchaseId + ", customerName="
				+ customerName + ", phoneno=" + phoneno + ", purchaseDate="
				+ purchaseDate + ", mobileId=" + mobileId + "]";
	}
	
	
}
