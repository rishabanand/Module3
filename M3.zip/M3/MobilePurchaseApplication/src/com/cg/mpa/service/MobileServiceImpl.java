package com.cg.mpa.service;

import java.util.List;

import com.cg.mpa.dao.MobileDao;
import com.cg.mpa.dao.MobileDaoImpl;
import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.MobilePurchase;
import com.cg.mpa.exception.MobileException;

public class MobileServiceImpl implements MobileService
{
	MobileDao mobDao=new MobileDaoImpl();
	@Override
	public List<Mobile> getAllMobiles() throws MobileException 
	{
		
		return mobDao.getAllMobiles();
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException 
	{
		
		return mobDao.getMobile(mid);
	}

	@Override
	public long insertPurchaseDetails(MobilePurchase pDetails)
			throws MobileException 
	{
		
		return mobDao.insertPurchaseDetails(pDetails);
	}

	

}
