package com.cg.mpa.dao;

public interface QueryMapper 
{
	String SELECT_ALL_MOBILES="SELECT mobileid,name,price,quantity FROM Mobiles";
	String SELECT_MOBILES="SELECT mobileId,name,price,quantity FROM Mobiles WHERE mobileid=?";
	String SELECT_SEQUENCE="SELECT pur_seq.NEXTVAL FROM dual";
	String INSERT_QUERY="INSERT INTO purchasedetails VALUES(?,?,?,?,?,?)";
}
