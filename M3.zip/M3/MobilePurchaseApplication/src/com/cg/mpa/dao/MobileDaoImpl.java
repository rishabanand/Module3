package com.cg.mpa.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cg.mpa.dto.Mobile;
import com.cg.mpa.dto.MobilePurchase;
import com.cg.mpa.exception.MobileException;
import com.cg.mpa.util.DBUtil;

public class MobileDaoImpl implements MobileDao
{
	Connection con=null;

	@Override
	public List<Mobile> getAllMobiles() throws MobileException 
	{
		List<Mobile> mList=new ArrayList<>();
		con=DBUtil.getCon();
		Statement st;
		try 
		{
			st = con.createStatement();
			ResultSet rs=st.executeQuery(QueryMapper.SELECT_ALL_MOBILES);
			while(rs.next())
			{
				Mobile m=new Mobile();
				m.setMobileId(rs.getLong("mobileid"));
				m.setMobileName(rs.getString("name"));
				m.setPrice(rs.getFloat("price"));
				m.setQuantity(rs.getInt("quantity"));
				mList.add(m);
			}
		}
		catch (SQLException e) 
		{			
			throw new MobileException("Problem in fetching mobileList"+e.getMessage());
		}
		return mList;
	}

	@Override
	public Mobile getMobile(long mid) throws MobileException 
	{
		Mobile m = null;
		con=DBUtil.getCon();
		PreparedStatement pst;
		try 
		{
			pst = con.prepareStatement(QueryMapper.SELECT_MOBILES);
			pst.setLong(1, mid);
			ResultSet rs=pst.executeQuery();
			if(rs.next())
			{
				 m = new Mobile();
				m.setMobileId(rs.getLong("mobileid"));
				m.setMobileName(rs.getString("name"));
				m.setPrice(rs.getFloat("price"));
				m.setQuantity(rs.getInt("quantity"));
			}
		} 
		catch (SQLException e) 
		{
		
			throw new MobileException("Problem in fetching"+e.getMessage());
		}
		
		
		return m;
	}

	private long generatePurchaseId()  throws MobileException 
	{
		long pid=0;
		con=DBUtil.getCon();
		Statement st;
		try 
		{
			st = con.createStatement();
			ResultSet rs=st.executeQuery(QueryMapper.SELECT_SEQUENCE);
			rs.next();
			pid=rs.getLong(1);
		} 
		catch (SQLException e)
		{
			throw new MobileException("Problem in generating purchase Id"+e.getMessage());
		}
		
		
		return  pid;
	}
	@Override
	public long insertPurchaseDetails(MobilePurchase pDetails)
			throws MobileException
	{
		con=DBUtil.getCon();
		pDetails.setPurchaseId(generatePurchaseId());
		try
		{
			PreparedStatement pst=con.prepareStatement(QueryMapper.INSERT_QUERY);
			pst.setLong(1, pDetails.getPurchaseId());
			pst.setString(2, pDetails.getCustomerName());
			pst.setString(3, pDetails.getMailId());
			pst.setString(4,pDetails.getPhoneno());
			pst.setDate(5, Date.valueOf(pDetails.getPurchaseDate()));
			pst.setLong(6, pDetails.getMobileId());
			pst.executeUpdate();
		}
		catch(SQLException e)
		{
			
		}
		return pDetails.getPurchaseId();
	}



}
